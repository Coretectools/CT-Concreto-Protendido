<?php
  ######################################################################
  # UNIVERSIDADE FEDERAL DE CATALÃO (UFCAT)
  # WANDERLEI MALAQUIAS PEREIRA JUNIOR,        ENG. CIVIL / PROF (UFCAT)
  # LUANNA LOPES LOBATO,                            COMP. / PROF (UFCAT)
  # THIAGO JABUR BITTAR,                            COMP. / PROF (UFCAT)
  # CARLOS MAGNO SILVA CARNEIRO,                      ENG. CIVIL (UFCAT)
  # WALFRIDO CARVALHO VALE,                         ENG. CIVIL (IAM ENG)
  # WALTER ALBERGARIA JUNIOR,                              COMP. (UFCAT)
  ######################################################################

  ######################################################################
  # DESCRIÇÃO ALGORITMO
  #
  # BIBLIO. DE PERDAS DE PROTENSÃO EM PEÇAS DE CONCRETO PROTENDIDO
  ######################################################################

  ######################################################################
  # BIBLIOTECAS DESENVOLVEDORES DO GPEE
  # PERDA POR ATRITO
  function PERDA_ATRITO_0001($P_IT0, $X, $ALPHA, $MU, $K, $A_P, $SIGMA_PIT0)
  {
    /*  
    ESTA FUNÇÃO DETERMINA A PERDA DE PROTENSÃO POR ATRITO DE UMA SEÇÃO DE
    UMA PEÇA DE CONCRETO PROTENDIDO

    ENTRADA:
    $P_IT0: CARGA INICIAL DE PROTENSÃO EM kN (FLOAT)
    $X: DISTÂNCIA DA SEÇÃO TRANSVERSAL EM m (FLOAT)
    $ALPHA: SOMATÓRIO DOS ÂNGULOS EM rad (FLOAT)
    $MU: COEFICIENTE DE ATRITO EM 1/rad (FLOAT)
    $K: COEFICIENTE DE PERDA DEVIDO A CURVATURA EM 1/m (FLOAT)
    $A_P: ÁREA DE AÇO DA ARMADURA PROTENDIDA EM cm² (FLOAT)
    $SIGMA_PIT0: TENSÃO INICIAL DE PROTENSÃO EM kN/cm² (FLOAT)
    
    SAÍDA:
    $DELTAP: PERDA DE PROTENSÃO EM kN (FLOAT)
    $P_IT1: CARGA FINAL DE PROTENSÃO APÓS AS PERDAS EM kN (FLOAT)
    $DELTAPERC: PERDA PERCENTAL EM % (FLOAT)
    $SIGMA_PIT1: TENSÃO FINAL DE PROTENSÃO APÓS AS PERDAS EM kN (FLOAT)
    $DELTASIGMA: PERDA DE PROTENSÃO EM kN/cm² (FLOAT)
    */
    # PERDA DE PROTENSÃO
    $AUX_1 = $MU * $ALPHA;
    $AUX_2 = $K * $X;
    $AUX_3 = ($AUX_1 + $AUX_2);
    $AUX_4 = exp(- $AUX_3);
    $DELTAP = $P_IT0 * (1 - $AUX_4);
    $P_IT1 = $P_IT0 * ($AUX_4);
    $DELTAPERC = ($DELTAP / $P_IT0) * 100;
    $SIGMA_PIT1 = $SIGMA_PIT0 * (1 - $DELTAPERC / 100);
    $DELTASIGMA = $SIGMA_PIT0 - $SIGMA_PIT1;
    # IMPRESSÕES AUXILIARES PARA CONFERÊNCIA APÓS FINALIZAR NA PLATAFORMA DEIXAR COMENTADO AS LINHAS DE IMPRESSÃO
    echo "---------------------------------------------------\n";
    echo "CORETECTOOLS - CONCRETO PROTENDIDO              \n";
    echo "CÁLCULO DA PERDA DE PROTENSÃO POR ATRITO        \n";
    echo "---------------------------------------------------\n\n";
    echo "--------------------------------------------------\n";
    echo "PARÂMETROS DE ENTRADA:\n";
    echo "--------------------------------------------------\n";
    echo "Carga de protensão Inicial (Pi)   = $P_IT0 kN\n";
    echo "Ap cabos                          = $A_P cm²\n";
    echo "Tensão de Protensão (σPi)         = $SIGMA_PIT0 kN/cm²\n";
    echo "Abscissa do cabo (x)              = $X cm\n";
    echo "Ângulo de desvio (α)              = $ALPHA radiano\n";
    echo "Coeficiente de atrito (µ)         = $MU 1/radiano\n";
    echo "Coeficiente de perda (k)          = $K 1/cm\n";
    echo "--------------------------------------------------\n\n";
    echo "--------------------------------------------------\n";
    echo "CARGA DE PROTENSÃO APÓS CONSIDERAÇÃO DA PERDA:\n";
    echo "--------------------------------------------------\n";
    echo "Parcela µ.α         = $AUX_1 \n";
    echo "Parcela k.x         = $AUX_2\n";
    echo "Parcela µ.α+k.x     = $AUX_3 \n";
    echo "Parcela e^()        = $AUX_4 \n";
    echo "Perda Pi            = $DELTAP kN\n";
    echo "Perda σPi           = $DELTASIGMA kN/cm²\n";
    echo "Percentual de perda = $DELTAPERC %\n";
    echo "--------------------------------------------------\n\n";
    return array($DELTAP, $P_IT1, $DELTAPERC, $SIGMA_PIT1, $DELTASIGMA);
  }

  # PERDA POR DESLIZAMENTO DA ANCORAGEM
  function PERDA_DESANC_0001($P_IT0, $A_P, $SIGMA_PIT0, $L_0, $DELTA_ANC, $E_P)
  {
    /*  
    ESTA FUNÇÃO DETERMINA A PERDA DE PROTENSÃO POR DESLIZAMENTO NA 
    ANCORAGEM EM PEÇAS PRÉ-FABRICADAS PROTENDIDAS EM PRÉ-TRAÇÃO

    ENTRADA:
    $P_IT0: CARGA INICIAL DE PROTENSÃO EM kN (FLOAT)
    $A_P: ÁREA DE AÇO DA ARMADURA PROTENDIDA EM cm² (FLOAT)
    $SIGMA_PIT0: TENSÃO INICIAL DE PROTENSÃO EM kN/cm² (FLOAT)
    $L_0: COMPRIMENTO DA PISTA DE PROTENSÃO EM cm (FLOAT)
    $DELTA_ANC: PREVISÃO DE DESLIZAMENTO NO SISTEMA DE ANCORAGEM EM cm (FLOAT)
    $E_P: MÓDULO DE YOUNG DO AÇO PROTENDIDO em kN/cm²
    
    SAÍDA:
    $DELTAP: PERDA DE PROTENSÃO EM kN (FLOAT)
    $P_IT1: CARGA FINAL DE PROTENSÃO APÓS AS PERDAS EM kN (FLOAT)
    $DELTAPERC: PERDA PERCENTAL EM % (FLOAT)
    $SIGMA_PIT1: TENSÃO FINAL DE PROTENSÃO APÓS AS PERDAS EM kN (FLOAT)
    $DELTASIGMA: PERDA DE PROTENSÃO EM kN/cm2 (FLOAT)
    */
    # PERDA DE PROTENSÃO
    $DELTAL_P = $L_0 * ($SIGMA_PIT0 / $E_P);
    $DELTAEPSILON_P = $DELTA_ANC / ($L_0 +  $DELTAL_P);
    $DELTASIGMA = $E_P * $DELTAEPSILON_P;
    $SIGMA_PIT1 = $SIGMA_PIT0 - $DELTASIGMA;
    $DELTAP = $DELTASIGMA * $A_P;
    $P_IT1 = $SIGMA_PIT1 * $A_P;
    $DELTAPERC = ($DELTAP / $P_IT0) * 100;
    # IMPRESSÕES AUXILIARES PARA CONFERÊNCIA APÓS FINALIZAR NA PLATAFORMA DEIXAR COMENTADO AS LINHAS DE IMPRESSÃO
    echo "---------------------------------------------------\n";
    echo "CORETECTOOLS - CONCRETO PROTENDIDO                     \n";
    echo "CÁLCULO DA PERDA DE PROTENSÃO POR DESLIZAMENTO AN-\nCORAGEM NA PRÉ TRAÇÃO\n";
    echo "---------------------------------------------------\n\n";
    echo "--------------------------------------------------\n";
    echo "PARÂMETROS DE ENTRADA:\n";
    echo "--------------------------------------------------\n";
    echo "Carga de protensão Inicial (Pi)        = $P_IT0 kN\n";
    echo "Tensão de protensão (σPi)              = $SIGMA_PIT0 kN/cm²\n";
    echo "Comprimento da pista de protenão (x)   = $L_0 cm\n";
    echo "Escorregamento (δ_anc)                 = $DELTA_ANC cm\n";
    echo "Área da seção transvesal do cabo (As)  = $A_P cm²\n";
    echo "Módulo de elasticidade do aço (E)      = $E_P kN/cm²\n";
    echo "--------------------------------------------------\n\n";
    echo "--------------------------------------------------\n";
    echo "CARGA DE PROTENSÃO APÓS CONSIDERAÇÃO DA PERDA:\n";
    echo "--------------------------------------------------\n";
    echo "ΔL_p                    = $DELTAL_P cm\n";
    echo "Δε_                     = $DELTAEPSILON_P cm/cm\n";
    echo "Perda P_i               = $DELTAP kN\n";
    echo "Perda σ_Pi              = $DELTASIGMA kN/cm²\n";
    echo "Percentual de perda     = $DELTAPERC %\n";
    echo "--------------------------------------------------\n\n";
    #ARMAZENAMENTO RESULTADOS
    return array($DELTAP, $P_IT1, $DELTAPERC, $SIGMA_PIT1, $DELTASIGMA);
  }

  /*
  # PERDA POR RELAXAÇÃO INICIAL DA ARMADURA
  function PERDA_REL_ARM_0001($P_IT0, $A_P, $SIGMA_PIT0, $T0, $T1, $PSI_1000)
  {
    # PERDA DE PROTENSÃO
    $RESULTADOEXP = pow((($T1 - $T0)/1000), 0.15);
    $PSI_DELTAT1 = $PSI_1000 * $RESULTADOEXP;
    $DELTASIGMA_PIT1 = ($PSI_DELTAT1/100) * $SIGMA_PIT0;
    $DELTAP_IT1 = $DELTASIGMA_PIT1 / $A_P;
    $P_IT1 = $P_IT0 - $DELTAP_IT1;
    $SIGMA_PIT1 = $SIGMA_PIT0 - $DELTASIGMA_PIT1;
    $DELTAPERC_PIT1 = ($DELTAP_IT1 / $P_IT0) * 100;

    $PSI_INF = 2.5 * $PSI_1000;
    $DELTASIGMA_PIT_INF = ($PSI_INF/100) * $SIGMA_PIT0;
    $DELTAP_IT_INF = $DELTASIGMA_PIT_INF / $A_P;
    $P_IT_INF= $P_IT0 - ($DELTASIGMA_PIT_INF / $A_P);
    $SIGMA_PI_INF = $SIGMA_PIT0 - $DELTASIGMA_PIT_INF;
    $DELTAPERC_PIT_INF = ($DELTAP_IT_INF / $P_IT0) * 100;

    # IMPRESSÕES AUXILIARES PARA CONFERÊNCIA APÓS FINALIZAR NA PLATAFORMA DEIXAR COMENTADO
    echo "---------------------------------------------------\n";
    echo "CORETECTOOLS - CONCRETO PROTENDIDO                     \n";
    echo "CÁLCULO DA PERDA DE PROTENSÃO POR RELAXAÇÃO\nINICIAL DA ARMADURA\n";
    echo "---------------------------------------------------\n\n";
    echo "--------------------------------------------------\n";
    echo "PARÂMETROS DE ENTRADA:\n";
    echo "--------------------------------------------------\n";
    echo "Carga de protensão Inicial (Pi)       = $P_IT0 kN\n";
    echo "Área da seção transvesal do cabo (As) = $A_P cm²\n";
    echo "Tensão de protensão (σPi)             = $SIGMA_PIT0 MPa\n";
    echo "Tempo inicial à protensão (T0)       = $T0 horas\n";
    echo "Tempo final à protensão (T1)         = $T1 horas\n";
    echo "--------------------------------------------------\n\n";
    echo "--------------------------------------------------\n";
    echo "CARGA DE PROTENSÃO APÓS CONSIDERAÇÃO DA PERDA:\n";
    echo "--------------------------------------------------\n";
    echo "Carga Pi(x=0)                 = $P_IT0 kN\n";
    echo "σPi(x=0)                      = $SIGMA_PIT0 MPa\n";
    echo "Carga Pi(x)                   = $P_IT1 kN\n";
    echo "σPi(x)                        = $SIGMA_PIT1 MPa\n";
    echo "Carga Pi(x=infinito)          = $P_IT_INF kN\n";
    echo "σPi(x=infinito)               = $SIGMA_PI_INF MPa\n";
    echo "Perda Pi                      = $DELTAP_IT1 kN\n";
    echo "Perda σPi                     = $DELTASIGMA_PIT1 MPa\n";
    echo "Percentual de perda           = $DELTAPERC_PIT1 %\n";
    echo "Perda Pi (infinito)           = $DELTAP_IT_INF kN\n";
    echo "Perda σPi (infinito)          = $DELTASIGMA_PIT_INF MPa\n";
    echo "Percentual de perda (infinito)= $DELTAPERC_PIT_INF %\n";
    echo "--------------------------------------------------\n\n";

    #ARMAZENAMENTO RESULTADOS
    $RESULTADOS_REL_ARM[1]  = $PSI_DELTAT1;
    $RESULTADOS_REL_ARM[2]  = $DELTASIGMA_PIT1;
    $RESULTADOS_REL_ARM[3]  = $DELTAP_IT1;
    $RESULTADOS_REL_ARM[4]  = $P_IT1;
    $RESULTADOS_REL_ARM[5]  = $SIGMA_PIT1;
    $RESULTADOS_REL_ARM[6]  = $DELTAPERC_PIT1;
    $RESULTADOS_REL_ARM[7]  = $PSI_INF;
    $RESULTADOS_REL_ARM[8]  = $DELTASIGMA_PIT_INF;
    $RESULTADOS_REL_ARM[9]  = $DELTAP_IT_INF;
    $RESULTADOS_REL_ARM[10] = $P_IT_INF;
    $RESULTADOS_REL_ARM[11] = $SIGMA_PI_INF;
    $RESULTADOS_REL_ARM[12] = $DELTAPERC_PIT_INF;

    #return $RESULTADOS_REL_ARM;
    #return $DELTAL_P, $DELTAEPSILON_P, $DELTASIGMA, $SIGMA_PIT1, $DELTAP, $P_IT1, $DELTAPERC;
  }

  # PERDA POR DEFORMAÇÃO INICIAL
  function PERDA_DEF_INICIAL_0001($E_P; $E_CI; $FPTK; $A_P; $I_C; $GAMA_B; $APCG; $A_C; $L_0; $GPP)
  {
    # PERDA DE PROTENSÃO
    $ALPHA_P     = $E_P/$E_CI;
    $EX_P        = $GAMA_B-$APCG;
    $SIGMA_PA    = 0.77*$FPTK;
    $PA          =(($SIGMA_PA*1000000/10000)*$A_P)/1000; 
    $MPP         = ($GPP*$L_0*$L_0)/8;
    $ACH         = $A_C;
    $I_H         = $I_C;
    $SIGMA_CP    = ($MPP*$EX_P/$I_H)-($PA/$ACH)-(($PA*$EX_P*$EX_P)/$I_H);

    # IMPRESSÕES AUXILIARES PARA CONFERÊNCIA APÓS FINALIZAR NA PLATAFORMA DEIXAR COMENTADO
    echo "---------------------------------------------------\n";
    echo "CORETECTOOLS - CONCRETO PROTENDIDO                     \n";
    echo "CÁLCULO DA PERDA DE PROTENSÃO POR DEFORMAÇÃO INICIAL\n";
    echo "---------------------------------------------------\n\n";
    echo "--------------------------------------------------\n";
    echo "PARÂMETROS DE ENTRADA:\n";
    echo "--------------------------------------------------\n";
    echo "Módulo de elasticidade do aço (E)         = $E_P MPa\n";
    echo "Módulo de elasticidade inicial            = $E_CI MPa\n";
    echo "Resistência a tração do aço na ruptura    = $FPTK MPa\n";
    echo "Área da armadura de protensão             = $A_P cm2\n";
    echo "Área da seção bruta                       = $A_C cm2\n";
    echo "Momento de inercia na seção bruta (I)     = $I_C cm4\n";
    echo "Altura do CG da peça                      = $GAMA_B cm\n";
    echo "Altura do centro da armadura de protensão = $APCG cm\n";
    echo "Vão da viga                               = $L_0 cm\n";
    echo "Peso próprio da viga                      = $GPP cm\n";
    echo "--------------------------------------------------\n\n";
    echo "--------------------------------------------------\n";
    echo "CARGA DE PROTENSÃO APÓS CONSIDERAÇÃO DA PERDA:\n";
    echo "--------------------------------------------------\n";
    echo "Razão modular                 = $ALPHA_P MPa\n";
    echo "Excentricidade da armadura de protensão = $EX_P cm\n";
    echo "Tensão na armadura de protensão     = $SIGMA_PA MPa\n";
    echo "Força de protensão ancorada     = $PA kN\n";
    echo "Momento fletor máximo devido ao peso próprio = $MPP kNcm\n";
    echo "Área da seção homogenizada     = $ACH cm2\n";
    echo "Momento de inércia da seção homogenizada = $I_H cm4\n";
    echo "Tensão concreto em determinada seção ao nivel da armadura de protensão = $SIGMA_CP MPa\n";
    echo "--------------------------------------------------\n\n";

    #ARMAZENAMENTO RESULTADOS
    $RESULTADOS_DEF_INICIAL[1] = $ALPHA_P;
    $RESULTADOS_DEF_INICIAL[2] = $EX_P;
    $RESULTADOS_DEF_INICIAL[3] = $SIGMA_PA;
    $RESULTADOS_DEF_INICIAL[4] = $PA;
    $RESULTADOS_DEF_INICIAL[5] = $MPP;
    $RESULTADOS_DEF_INICIAL[6] = $ACH;
    $RESULTADOS_DEF_INICIAL[7] = $I_H;
    $RESULTADOS_DEF_INICIAL[7] = $SIGMA_CP;

    #return $RESULTADOS_DEF_INICIAL;
    #return $ALPHA_P, $EX_P, $SIGMA_PA, $PA, $MPP, $ACH, $I_H, $SIGMA_CP
  }

  # PERDA POR RETRAÇÃO DO CONCRETO
  function PERDA_RETRACAO_CONC_0001 ()
  {
    # PERDA DE PROTENSÃO
    $expoenteparte1 = -7.8 + 0.1*$U;
    $expoenteparte2 = exp($expoenteparte1);
    $gama = 1 + $expoenteparte2;
    $hfic = ($gama * 2 * $Ac) / $miar;

    $epsilon1sparte1 = 8.09;
    $epsilon1sparte2 = $U/15;
    $epsilon1sparte3 = pow($U,2) / 2.284;
    $epsilon1sparte4 = pow($U,3) / 133.765;
    $epsilon1sparte5 = pow($U,4) / 7608.150;
    $epsilon1sfinal = (-$epsilon1sparte1+$epsilon1sparte2-$epsilon1sparte3-$epsilon1sparte4+$epsilon1sparte5) * 0.0001;

    if ($abat >= 0 && $abat <= 4) {
    $epsilon1s = 0.75 * $epsilon1sfinal;
    }elseif ($abat >= 5 && $abat <= 9) {
    $epsilon1s = $epsilon1sfinal;
    }elseif ($abat >= 10 && $abat <= 15) {
    $epsilon1s = 1.25 * $epsilon1sfinal;     
    }

    $epsilon2sparte1 = 33 + (2 * $hfic);
    $epsilon2sparte2 = 20.8 + (3 * $hfic);
    $epsilon2s = $epsilon2sparte1 / $epsilon2sparte2;

    $epsiloncsinf = $epsilon1s * $epsilon2s;
    $deltasigmapcsinf = $epsiloncsinf * $Ep;
    $deltaPinf = $deltasigmapcsinf / $Ac;
    $Pinf = $Pi - $deltaPinf;
    $Pinfporcent = $deltaPinf / $Pi;
    $t = (($Ti + 10) * $deltatef) / 30;

    $h = $hfic / 10;

    if ($h < 0.05) {
      $h = 0.05;
    } elseif ($h > 1.6) {
      $h = 1.6;
    } else
      $h = $h;

    $A = 40;
    $B = 116 * pow($h, 3) - 282 * pow($h, 2) + 220 * $h - 4.8;
    $C = 2.5 * pow($h, 3) - 8.8 * $h + 40.7;
    $D = -75 * pow($h, 3) + 585 * pow($h, 2) + 496 * $h - 6.8;
    $E = -169 * pow($h, 4) + 88 * pow($h, 3) + 584 * pow($h, 2) + 0.8;

    $betast0parte1 = pow((0.01 * $t0), 3);
    $betast0parte2 = $A * pow((0.01 * $t0), 2);
    $betast0parte3 = $B * 0.01 * $t0;
    $betast0parte4 = $C * pow((0.01 * $t0), 2);
    $betast0parte5 = $D * 0.01 * $t0;
    $betast0parte6 = $E;

    $betast0 = ($betast0parte1+$betast0parte2+$betast0parte3)/($betast0parte1+$betast0parte4+$betast0parte5+$betast0parte6);

    $A = 40;
    $B = 116 * pow($h, 3) - 282 * pow($h, 2) + 220 * $h - 4.8;
    $C = 2.5 * pow($h, 3) - 8.8 * $h + 40.7;
    $D = -75 * pow($h, 3) + 585 * pow($h, 2) + 496 * $h - 6.8;
    $E = -169 * pow($h, 4) + 88 * pow($h, 3) + 584 * pow($h, 2) + 0.8;

    $betastparte1 = pow(0.01 * $t, 3);
    $betastparte2 = $A * pow(0.01 * $t, 2);
    $betastparte3 = $B * 0.01 * $t;
    $betastparte4 = $C * pow(0.01 * $t, 2);
    $betastparte5 = $D * 0.01 * $t;
    $betastparte6 = $E;

    $betast = ($betastparte1+$betastparte2+$betastparte3)/($betastparte1+$betastparte4+$betastparte5+$betastparte6);

    $epsiloncst = $epsiloncsinf * ($betast - $betast0);
    $deltasigmapcs = $epsiloncst * $Ep;
    $deltaP = $deltasigmapcs / $Ac;
    $P = $Pi - $deltaP;
    $Pporcent = $deltaP / $Pi;

  }

  # PERDA POR FLUÊNCIA DO CONCRETO
  function PERDA_FLUENCIA_CONC_0001 ($T0; $T; $U; $S; $T28; $A_C; $FCK)
  {
    # PERDA DE PROTENSÃO
    $GAMA      = 1+exp(-7.8+0.1*$U);
    $H_FIC_T   = $GAMA*2*$A_C/$U;
    if ($H_FIC_T<0.05) {
    $H_FIC_T = 0.05;
    } elseif ($H_FIC_T>1.6) {
    $H_FIC_T = 1.6;
    } else { 
    $H_FIC_T = ($GAMA*2*$A_C)/$U;
    }
    $H2 = $H_FIC_T*$H_FIC_T;
    $H3 = $H2*$H_FIC_T;
    $A  = 42*$H3-350*$H2+588*$H_FIC_T+113;
    $B  = 768*$H3-3060*$H2+3234*$H_FIC_T-23;
    $C  = -200*$H3+13*$H2+1090*$H_FIC_T+183;
    $D  = 7579*$H3-31916*$H2+35343*$H_FIC_T+1931;
    $BETAF_T = (1*$T*$T+$A*$T+$B)/($T*$T+$D);
    $BETAF_T0 = (1*$T0*$T0+$A*$T0+$B)/($T0*$T0+$D);
    $BeTaf = $BETAF_T-$BETAF_T0;

    $BETA1_T  = exp($S*(1-sqrT(28/$T)));
    $BETA128  = exp($S*(1-sqrT(28/$T28)));

    if ($FCK<45) {
    $FI_A = 0.8*(1-($BETA1_T/$BETA128));
    } else  {
    $FI_A = 1.4*(1-($BETA1_T/$BETA128));
    } 

    if ($U<90) {
    $FI1C = 4.45-0.035*$U;
    } else  {
    $FI1C = 0.8;
    }

    $FI2C  = (0.42+$H_FIC_T)/(0.2+$H_FIC_T);
    $FIF  = $FI1C*$FI2C;
    $BETAD = (($T-$T0)+20)/(($T-$T0)+70);

    $FID  = 0.4;
    $FITT = $FI_A+$FIF*$BeTaf+$FID*$BETAD;

    # IMPRESSÕES AUXILIARES PARA CONFERÊNCIA APÓS FINALIZAR NA PLATAFORMA DEIXAR COMENTADO
    echo "---------------------------------------------------\n";
    echo "CORETECTOOLS - CONCRETO PROTENDIDO              \n";
    echo "CÁLCULO DA PERDA DE PROTENSÃO POR FLUENCIA DO CONCRETO\n";
    echo "---------------------------------------------------\n\n";
    echo "--------------------------------------------------\n";
    echo "PARÂMETROS DE ENTRADA:\n";
    echo "-----------------------------------------------\n";
    echo "Período inicial                      = $T0 dias\n";
    echo "Período final                         = $T dias\n";
    echo "Umidade relaTiva do ambienTe             = $U %\n";
    echo "CoeficienTe relacionado ao Tipo cimenTo   = $S \n";
    echo "Área da seção de concreTo              =$A_C cm2\n";
    echo "FCK do concreTo                       =$FCK MPa\n";
    echo "--------------------------------------------------\n\n";
    echo "-----------------------------------------------\n";
    echo "CARGA DE PROTENSÃO APÓS CONSIDERAÇÃO DA PERDA:\n";
    echo "-----------------------------------------------\n";
    echo "CoeficienTe FI_A  = $FI_A \n";
    echo "CoeficienTe de fluência final  = $FITT \n";
    echo "--------------------------------------------------\n\n";

    #ARMAZENAMENTO RESULTADOS
    $RESULTADOS_FLUENCIA_CONCRETO[1] = $FI_A;
    $RESULTADOS_FLUENCIA_CONCRETO[2] = $FITT;

    #return $RESULTADOS_FLUENCIA_CONCRETO;
    #return $FI_A, $FITT
    }
    */
?>